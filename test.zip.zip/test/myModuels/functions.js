import{eventPath,jsonPath,eventEmitter} from "./emitters_paths.js";
import fs from "fs";

const readFunction=(data)=>{
    data=JSON.parse(fs.readFileSync(path, {encoding: "utf-8"}));
    return data
}

const toStr = (data)=>{
    JSON.stringify(data)
    return data
}

const pushData = (path,data)=>{
fs.appendFileSync(jsonPath,data)
}
    
// To add function
export const addStudens=(id,studentFullname, studentEmail, studentPassword)=>{

      const newStudent={
        id : null,
        fullName : studentFullname,
        email : studentEmail,
        password : studentPassword
       } 
    
    toStr(newStudent);
    pushData(jsonPath,newStudent);
    eventEmitter.emit("greeting",newStudent.fullName)

}