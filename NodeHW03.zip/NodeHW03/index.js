import {v4 as randomId} from 'uuid';
import color from "colors";
import {myeventEmitter} from "./myModuls/service.js";




console.log('Home Work'.blue)

//To Write in freeting_log.txt
myeventEmitter.emit("runGreet","\nJoe");

//To write in students.json - bonus question, and the new sutend will be added in a new line :)
myeventEmitter.emit("runJson","Ace");
myeventEmitter.emit("runJson","Gale");
myeventEmitter.emit("runJson","Gjorge");
myeventEmitter.emit("runJson","Aneta");

// Ne bese jasno, kako da Deletnam user do Id, potocno kako bi go znajal id to za da mozam da go deletnam, logikata if input ID === studen.id , remove student, toa bi go taka napravil, ama ne mi e jasno kako bi go znajal id-to vo prv slucaj za da go trazam