import color from 'colors'
import {v4 as IDRandom} from 'uuid';
// import{eventPath,jsonPath,eventEmitter} from "./myModuels/emitters_paths.js";
import {addStudens} from "./myModuels/functions.js";



console.log('Home-Work03'.blue);

addStudens(IDRandom(),"Joe Bill","bill@gmail.com");