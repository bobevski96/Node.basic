import {EventEmitter} from "events"; 

 export const myeventEmitter = new EventEmitter();

 myeventEmitter.on("run", (studentFullname, studentEmail, studentPassword,id) => {
    const newStudent = {
        studentFullname: studentFullname,
        eMail : studentEmail,
        password : studentPassword,
        id : id,
    }
   
    greeting=()=>{
        console.log(`Greeing from ${newStudent.studentFullname} with an ID : ${newStudent.id}`);
    }
});


