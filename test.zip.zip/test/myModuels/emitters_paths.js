import {EventEmitter} from "events"; 
import fs from "fs";
import path from "path"

// Path to greeting.txxt and students.json
export let eventPath=path.join("./greeting_log.txt");
fs.writeFileSync(eventPath,'Home-Work');

/// imam prasanje, na slednata linia kod, jas samo mu kazuvam deka da mi go kreira noviot file, no avtomacki i toa go pisuva vo nego kako writeFileSync
export let jsonPath = path.join("./students.json")

// fs.writeFileSync(jsonPath,"To Json")
// Test
// fs.writeFileSync(jsonPath,"Hello")

export const eventEmitter = new EventEmitter;

eventEmitter.on("greeting",(studentName)=>{
 fs.appendFileSync(eventPath,`\n ${studentName}`)
});  

    
