import {v4 as randomId} from 'uuid';
import color from "colors";
import {myeventEmitter} from "./myModuls/service.js";

console.log('Home Work'.blue)

myeventEmitter.emit("run",("Joe","joe@gmail.com","123awe",randomId));
